package me.everything.providers.core;

public interface EnumInt {
}
